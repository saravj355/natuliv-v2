/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testunit;

/**
 *
 * @author jlargor
 */
public class Testunit {

    public static String answer(int day, int number) {
        String dayString;
        switch (day) 
        {
            case 1:  if (number > 2) {
                         dayString = "Lunes";
                     }else {
                        dayString = "Sabado";
                     }   
                     break;
            case 2:  if (number < 2) {
                         dayString = "Martes";
                     }else {
                        dayString = "Domingo";
                     }  
                     break;
            case 3:  if (number < 2) {
                         dayString = "Miercoles";
                     }else {
                        dayString = "Jueves";
                     }  
                     break;
            case 5:  dayString = "Garantizar";
                     break;
            default: dayString = "Viernes";
                     break;
        }
        System.out.println(dayString);
        return dayString;
    }
    
}
