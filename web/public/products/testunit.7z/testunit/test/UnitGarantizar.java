/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import testunit.*;
/**
 *
 * @author jlargor
 */
public class UnitGarantizar {
    
    public UnitGarantizar() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void TestCase() {
        String esperado = "Martes";
        String resultado = Testunit.answer(2, 0);
      
        assertEquals(esperado, resultado);
    }
    
        @Test
    public void TestCase2() {
        String esperado = "Viernes";
       
        String resultado = Testunit.answer(4, 0);
        
        assertEquals(esperado, resultado);
    }
}
