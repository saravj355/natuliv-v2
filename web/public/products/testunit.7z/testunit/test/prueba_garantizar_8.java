/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jlargor
 */
public class prueba_garantizar_8 {
    
    public prueba_garantizar_8() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void hello_garantizar_1() {
        String resultado_esperado = "Domingo";
        int valor_dia = 2;
        int valor = 3;
        String Resultado_actual = testunit.Testunit.answer(valor_dia, valor);
        assertEquals(resultado_esperado, Resultado_actual);
        
    }
   @Test
    public void hello_garantizar_2() {
        String resultado_esperado = "Martes";
        int valor_dia = 2;
        int valor = 1;
        String Resultado_actual = testunit.Testunit.answer(valor_dia, valor);
        assertEquals(resultado_esperado, Resultado_actual);
    }
    @Test
    public void hello_garantizar_3() {
        String resultado_esperado = "Viernes";
        int valor_dia = 4;
        int valor = 1;
        String Resultado_actual = testunit.Testunit.answer(valor_dia, valor);
        assertEquals(resultado_esperado, Resultado_actual);
    }

}
