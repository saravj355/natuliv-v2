import { Selector, t } from "testcafe";
export default class login {
  constructor() {
    this.menuFlights = Selector('body > div:nth-child(5) > table > tbody > tr > td:nth-child(1) > table > tbody > tr > td > table > tbody > tr > td > table > tbody > tr:nth-child(2) > td:nth-child(2) > a');
  }
}