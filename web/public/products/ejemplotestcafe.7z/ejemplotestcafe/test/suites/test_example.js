import login from "../page_model/login";
import menu from "../page_model/menu";
import flightDetails from "../page_model/flightDetails";
const pagelogin = new login();
const pagemenu = new menu();
const flightdetails = new flightDetails();

fixture`Ejemplo page Object Model`
 .page`http://demo.guru99.com/test/newtours/`;
 test('Ejemplo Garantizar TestCafe', async t => {
    await t
        .typeText(pagelogin.userName, 'pepegarantizar') // Ingresar Usuario
        .wait(10)
        .typeText(pagelogin.password, 'pepegarantizar123') // Ingresar contraseña
        .wait(10)
        .click(pagelogin.submit) // click en Submit
        .wait(10)
        .click(pagemenu.menuFlights) // Ingresar al Menu flights
        .expect(flightdetails.passengers.value).eql('1'); // Comprobar resultado
 });





 test('Ejemplo Garantizar acapulco', async t => {
    await t
        .typeText(pagelogin.userName, 'pepegarantizar') // Ingresar Usuario
        //.wait(10)
        .typeText(pagelogin.password, 'pepegarantizar123') // Ingresar contraseña
        //.wait(10)
        .click(pagelogin.submit) // click en Submit
        //.wait(1000)
        .click(pagemenu.menuFlights) // Ingresar al Menu flights
        .expect(flightdetails.from.value).eql('Acapulco'); // Comprobar resultado
 });
